# Challenge Run Value (cRV): analysis code and synthetic validation corpus

This deposit accompanies the manuscript **"Challenge Run Value (cRV):
quantifying strategic value in MLB's ABS challenge era"** (submitted to the
*Journal of Quantitative Analysis in Sports*).

## Contents

- **Pipeline source** (`pipeline.py`, `ingestion.py`, `events.py`,
  `realities.py`, `re288.py`, `calculate.py`, `analysis.py`, `figures.py`):
  the five-module reproducible pipeline that fetches Statcast pitch data via
  `pybaseball`, isolates ABS challenge events, builds alternate umpire-call /
  overturned realities, maps them onto an RE288 run-expectancy surface, and
  scores each challenge as a run value with a time-decaying opportunity-cost
  penalty.
- **`synthetic_validation_corpus.csv`**: the deterministic, hand-designed
  corpus of ten challenge events that exercises every state-transition path
  (non-terminal count changes, bases-loaded walks, inning-ending strikeouts,
  extra-inning failures, parse-ambiguous descriptions). Used as the offline
  correctness harness.
- **`tests/`** (in `tests.zip`): the unit-test suite pinning the state
  transition rules.
- **`requirements.txt`**: Python dependencies.

## Reproduction

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python pipeline.py --output-dir outputs            # live 2026 Statcast run
python pipeline.py --output-dir outputs --force-synthetic   # offline corpus
python -m pytest tests/ -q
```

Real Statcast inputs are fetched at runtime through `pybaseball`; no MLB data
is redistributed here. The synthetic corpus is deterministic and regenerable
from `pipeline.py::_synthetic_challenge_data()`.

## License

[See the license recorded on the Zenodo record.]
